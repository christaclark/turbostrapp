# turbostrapp
turbostrapp.com


New Files for Bryan: 

index is the pricing slider 
welcome modal 
pricing table modal


CSS
The main.css file will need to be switched out with the updated one 
Also added the pricing.css
